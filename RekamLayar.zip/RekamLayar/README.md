# Rekam Layar

Aplikasi perekam layar Android (Kotlin, tanpa dependensi tambahan). Hasil disimpan di `Movies/RekamLayar`.

## Build lewat GitHub
1. Buat repository baru di GitHub, upload semua isi folder ini.
2. Buka tab **Actions** → workflow **Build APK** (otomatis jalan setiap push ke `main`).
3. Setelah selesai, unduh artifact **RekamLayar-debug** (berisi `app-debug.apk`).
4. Pasang APK di HP (izinkan instal dari sumber tidak dikenal).
