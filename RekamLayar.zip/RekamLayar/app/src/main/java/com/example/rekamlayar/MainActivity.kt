package com.example.rekamlayar

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var button: Button
    private lateinit var status: TextView
    private lateinit var audioBox: CheckBox

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        status = TextView(this).apply { textSize = 18f; gravity = Gravity.CENTER }
        audioBox = CheckBox(this).apply { text = "Rekam suara mikrofon"; isChecked = true }
        button = Button(this)
        root.addView(status)
        root.addView(audioBox)
        root.addView(button)
        setContentView(root)

        button.setOnClickListener {
            if (RecorderService.isRecording) stopRecording() else beginStart()
        }
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val rec = RecorderService.isRecording
        button.text = if (rec) "Berhenti Merekam" else "Mulai Merekam"
        status.text = if (rec) "Sedang merekam…" else "Siap merekam.\nHasil disimpan di Movies/RekamLayar"
        audioBox.isEnabled = !rec
    }

    private fun beginStart() {
        val perms = mutableListOf<String>()
        if (audioBox.isChecked && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            perms += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            perms += Manifest.permission.POST_NOTIFICATIONS
        if (perms.isNotEmpty()) requestPermissions(perms.toTypedArray(), REQ_PERM) else requestCapture()
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (code == REQ_PERM) {
            if (audioBox.isChecked && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                audioBox.isChecked = false
            requestCapture()
        }
    }

    private fun requestCapture() {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAPTURE && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, RecorderService::class.java).apply {
                action = RecorderService.ACTION_START
                putExtra(RecorderService.EXTRA_CODE, resultCode)
                putExtra(RecorderService.EXTRA_DATA, data)
                putExtra(RecorderService.EXTRA_AUDIO, audioBox.isChecked)
            }
            startForegroundService(i)
            RecorderService.isRecording = true
            refresh()
        }
    }

    private fun stopRecording() {
        startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_STOP))
        RecorderService.isRecording = false
        refresh()
    }

    companion object {
        private const val REQ_PERM = 1
        private const val REQ_CAPTURE = 2
    }
}
